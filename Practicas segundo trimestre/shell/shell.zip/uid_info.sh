#!/bin/bash

#Comprobar usuario
#-----------------

#Usuario
uid_buscado=$1

#Recorrer /etc/passwd línea por línea
while read linea
do
	#Extrae el usuario
	usuario=`echo $linea | cut -d ":" -f 1`
	#Extrae la UID
	uid=`echo $linea | cut -d ":" -f 3`
	#Comprobación
	if (($uid==$uid_buscado)); then
		echo El usuario es $usuario
		exit 0
	fi
done < /etc/passwd

#Mensaje final
echo El usuario con la UID $uid_buscado no existe
	
exit 0

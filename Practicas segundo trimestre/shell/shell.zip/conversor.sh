#!/bin/bash

#Conversor EUR-USD y USD-EUR
#-----------------------------------

#Cambio por defecto EUR-USD 12/03/2014
cambio="1.3862"

while true
do
	#Mensaje previo
	echo
	echo "Elija opción:"
	echo "1- Conversión EUR -> USD"
	echo "2- Conversión USD -> EUR"
	echo "3- Fijar nuevo cambio (cambio actual: 1 € -> $cambio \$)"
	echo "4- Fin"
	echo
	echo -n "Opción: "; read opcion
	echo

	#Opciones
	case $opcion in
		#EUR-USD
		1)	echo -n "Introduzca la cantidad en euros que desea convertir: "; read eur
			usd=`echo "scale=2; $eur * $cambio" | bc -l`
			echo
			echo Cantidad al cambio: $usd \$ 
			;;
		#EUR-USD
		2)	echo -n "Introduzca la cantidad en dolares que desea convertir: "; read usd
			eur=`echo "scale=2; $usd / $cambio" | bc -l`
			echo
			echo Cantidad al cambio: $eur € 
			;;
		#Fijar nuevo cambio
		3)	echo -n "Introduzca nuevo cambio EUR-USD: "; read cambio
			;;
		#Terminar
		4)	exit 0
			;;
		#Error
		*)	echo Introduzca una opción válida
			;;
	esac 
	
done

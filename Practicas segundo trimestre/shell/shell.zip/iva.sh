#!/bin/bash

#Conversor EUR-USD y USD-EUR
#-----------------------------------

#Tasa del IVA por defecto 12/03/2014
tasa="21"

while true
do
	#Mensaje previo
	echo
	echo "Elija opción:"
	echo "1- Aplicar tasa del IVA"
	echo "2- Fijar nueva tasa (tasa actual: $tasa%)"
	echo "3- Fin"
	echo
	echo -n "Opción: "; read opcion
	echo

	#Opciones
	case $opcion in
		#Aplicar IVA
		1)	echo -n "Introduzca la cantidad en euros a la que desea aplicar la tasa: "; read eur
			eur=`echo "scale=2; ( $eur * $tasa /100 ) + $eur" | bc -l`
			echo
			echo "Cantidad con IVA($tasa%): $eur €" 
			;;
		#Aplicar nueva tasa del IVA
		2)	echo -n "Introduzca nueva tasa del IVA: "; read tasa
			;;
		#Terminar
		3)	exit 0
			;;
		#Error
		*)	echo "Introduzca una opción válida"
			;;
	esac 
	
done

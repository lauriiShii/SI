#!/bin/bash

#Gestor de archivos
#------------------

#Comprobación y captura del archivo
if (($#<1)); then
	echo "SINTAXIS: gestor.sh ruta_archivo"
	exit 1
fi
if [ -f $1 ]; then
	archivo=`basename $1`
	ruta=`dirname $1`	
else
	echo "No existe el archivo"
	exit 1
fi

#Menu
echo 
echo "Elija la accion que desea realizar:"
echo "1- Mostrar contenido del archivo"
echo "2- Renombrar archivo"
echo "3- Mover archivo"
echo "4- Copiar archivo"
echo "5- Borrar archivo"
echo "Pulse cualquier otra tecla para cancelar..."
echo
echo -n "Opción: "; read opcion
echo	

#Opciones
case $opcion in
	#Mostrar archivo
	1)	cat $ruta/$archivo | more
		;;
	#Renombrar archivo
	2)	echo -n "Nuevo nombre: "; read nombre
		mv $ruta/$archivo $ruta/$nombre
		;;
	#Mover archivo
	3)	echo -n "Ruta de destino: "; read destino
		mv $ruta/$archivo $destino/$archivo
		;;
	#Copiar archivo
	4)	echo -n "Nuevo nombre: "; read nombre
		echo -n "Ruta de destino: "; read destino
		cp $ruta/$archivo $destino/$nombre
		;;
	#Copiar archivo
	5)	rm $ruta/$archivo
		;;
	#Terminar
	*)	exit 0
		;;
esac 

#Mensaje final
echo "Acción realidaza."
	
exit 0

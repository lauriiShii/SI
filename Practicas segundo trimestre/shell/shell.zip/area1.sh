#!/bin/bash

#Área (Versión 1)
#--------------

while true
do
	#Mensaje previo
	echo
	echo "Figura de la que desea calcular el área:"
	echo "1- Cículo"
	echo "2- Cuadrado"
	echo "3- Rectángulo"
	echo "4- Triángulo"
	echo "5- Fin"
	echo
	echo -n "Opción: "; read opcion
	echo

	#Opciones
	case $opcion in
		#Área del círculo
		1)	echo -n "Introduzca el radio: "; read r
			area=`echo "3.1415927 * $r * $r " | bc -l`
			;;
		#Área del cuadrado
		2)	echo -n "Introduzca el lado "; read l
			area=`echo "$l * $l" | bc -l`
			;;
		#Área del rectángulo
		3)	echo -n "Introduzca la base "; read b
			echo -n "Introduzca la altura "; read h
			area=`echo "$b * $h" | bc -l`
			;;
		#Área del triángulo
		4)	echo -n "Introduzca la base "; read b
			echo -n "Introduzca la altura "; read h
			area=`echo "$b * $h /2" | bc -l`
			;;
		#Terminar
		5)	exit 0
			;;
		#Error
		*)	echo Introduzca una opción válida
			;;
	esac 

	#Mensaje final	
	echo El área es $area
	
done

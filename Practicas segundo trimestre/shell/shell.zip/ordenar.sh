#!/bin/bash

#Ordenar vector
#--------------

#Comprobación de argumentos
if (($#<2)); then
	echo Sintaxis: bash ordenar.sh elemento elemento...
	exit 1
fi

#Mensaje previo
echo
echo Vector de entrada: $*
echo 

#Captura de elementos
n=0
for e in $* 
do 
	v[$n]=$e
	let n++
done

#Algoritmo de la burbuja
let lim_i=n
let lim_j=n-1

for ((i=1; $i<$lim_i; i++)){
	for ((j=0; $j<$lim_j; j++)){
		let k=j+1
		if ((${v[$j]}>${v[$k]})); then
			aux=${v[$j]}
			v[$j]=${v[$k]}
			v[$k]=$aux
		fi
	}
}

#Mostrar resultado
echo Vector ordenado: ${v[*]}

exit 0

#!/bin/bash

#QUIZ (El juego de moda)
#----------------------

#Archivo de preguntas
mazo="./quiz_mazo"
if [ -f $mazo ]; then
	echo "Bienvenido a QUIZ, el juego de las preguntas locas..."
	echo
	echo "Escribe todas las respuestas en minúsculas y sin signos de puntuación ni acentuación."
	echo 
else
	echo "No está disponible el archivo de preguntas."
	exit 1
fi

#Número de jugadores
until (( (n_jugadores >= 1) && (n_jugadores <= 5) ))
do
	echo -n "Número de jugadores: "; read n_jugadores
done

#Número de rondas
rondas=0
until (( (rondas >= 1) && (rondas <= 100) ))
do
	echo -n "Número de rondas (1-100): "; read rondas
done

#Inicializar jugadores
for ((i=1; $i<=$n_jugadores ; i++)) {
	echo -n "Escriba el nombre para el jugador $i: "; read nombres[$i]
	score[$i]=0
}

#Número de preguntas que tiene el fichero de preguntas
let n_preguntas=`wc -l $mazo | cut -d " " -f 1`/2      

#Bucle de rondas
for ((r=1; $r<=$rondas ; r++)) {
	
	echo "RONDA $r"
	echo "--------"
	
	#Bucle de turnos
	for ((t=1; $t<=$n_jugadores ; t++)) {
		
		echo "Turno de ${nombres[$t]}"
		echo "(${score[$t]} preguntas acertadas)"
		echo
		
		#Leer pregunta aleatoria
		let n=($RANDOM%$n_preguntas)
		
		#Hacer pregunta
		let np=(n*2)+1
		pregunta=`awk "NR==$np" $mazo`
		echo $pregunta
		
		#Tomar respuesta
		let nr=(n*2)+2
		respuesta=`awk "NR==$nr" $mazo`
		echo -n "Respuesta: "; read respuesta_jugador
		
		#Verificar respuesta
		if [ "$respuesta" = "$respuesta_jugador" ]; then
			echo "CORRECTO"
			echo
			let score[$t]++
		else
			echo "INCORRECTO"
			echo "La respuesta es $respuesta"
			echo
		fi
	}
}
#Mostrar ganador y estadisticas
echo
echo "RESULTADOS"
echo "----------"
ganador=1
for ((j=1; $j<=$n_jugadores ; j++)) {
	porcentaje=`echo "scale=0; ${score[$j]}*100/$rondas" | bc -l` 
	echo "Jugador $j: ${nombres[$j]}	${score[$j]} aciertos	($porcentaje%)"
	if (( score[$j] > score[$ganador] )); then
		ganador=$j
	fi
}
echo
echo -n "Ganadores: "
for ((j=1; $j<=$n_jugadores ; j++)) {
	if (( score[$j] == score[$ganador] )); then
	  echo -n "${nombres[$j]} "
	fi
}
echo
echo "FELICIDADES"
echo
exit 0



#!/bin/bash

#Adivina un número
#-----------------

#Número aleatorio
numero=$RANDOM
let numero=(numero%10)+1

#Número apuesta
echo -n "Dime un número: "
read intento 

#1ª Comprobación
if (($numero==$intento)); then
	echo ¡¡Acertaste!!
	exit 0
else
	echo ¡¡Fallaste!!
	if (($numero<$intento)); then
		echo -n "El número es MENOR, inténtalo de nuevo: "
	else
		echo -n "El número es MAYOR, inténtalo de nuevo: "
	fi
	read intento
fi

#2ª Comprobación
if (($numero==$intento)); then
	echo ¡¡Acertaste!!
else
	echo ¡¡Fallaste de nuevo!!
	echo El número era el $numero
fi
	
exit 0

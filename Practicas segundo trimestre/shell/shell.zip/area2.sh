#!/bin/bash

#Área (Versión 2)
#--------------
#Función de ayuda 
ayuda (){
	echo
	echo "SINTAXIS:"
	echo "area2.sh -c radio		Calcula el área del círculo"
	echo "area2.sh -s lado		Calcula el área del cuadrado"
	echo "area2.sh -r base altura		Calcula el área del rectángulo"
	echo "area2.sh -t base altura		Calcula el área del triángulo"
	echo
}

#Comprobación y captura de la opción
if (($#<2)); then
	ayuda
	exit 1
else
	opcion=$1
fi

#Cálculo del área
case $opcion in
	#Área del círculo
	-c)	echo -n "Área del círculo: "
		area=`echo "3.1415927 * $2 * $2 " | bc -l`
		;;
	#Área del cuadrado
	-s)	echo -n "Área del cuadrado: "
		area=`echo "$2 * $2" | bc -l`
		;;
	#Área del rectángulo
	-r)	echo -n "Área del rectángulo: "
		area=`echo "$2 * $3" | bc -l`
		;;
	#Área del triángulo
	-t)	echo -n "Área del triángulo: "
		area=`echo "$2 * $3 /2" | bc -l`
		;;
	#Error
	*)	ayuda
		exit 1
		;;
esac 
#Mensaje final	
echo $area
	
exit 0
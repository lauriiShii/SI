#!/bin/bash

#Agenda
#------

#Comprobación y captura del archivo
if (($#<1)); then
	echo "SINTAXIS: gestor.sh ruta_archivo"
	exit 1
fi
if [ -f $1 ]; then
	archivo=`basename $1`
	ruta=`dirname $1`	
else
	echo "No existe el archivo"
	exit 1
fi

while true 
do
	#Mensaje previo
	echo
	echo "AGENDA DE TELÉFONOS"
	echo "1- Buscar un nombre en la agenda"
	echo "2- Introducir un nuevo nombre"
	echo "3- Borrar un nombre de la agenda"
	echo "4- Mostrar el contenido del $archivo"
	echo "5- Salir"
	echo
	echo -n "Opción: "; read opcion
	echo
	
	
	case $opcion 
	in
		#Buscar una palabra clave en la agenda
		1)	echo -n "Introduzca palabra clave a buscar: "; read clave
			
			#Recorrer archivo registro por registro
			while read registro 
			do
				#Recorrer registro campo por campo
				for ((c=1; $c<=4; c++)) {
				
					#Se compara cada campo con la clave, si coincide se muestra por pantalla
					campo=`echo $registro | cut -d ":" -f $c`
					if [ "$clave" = "$campo" ]
					then
						#Mostrar registro
						echo $registro | tr ":" "			"
					fi
				}
			done < $ruta/$archivo
			;;
		#Agregar una nueva entrada en la agenda
		2)	echo -n "Introduzca nombre: "; read nombre
			echo -n "Introduzca apellidos: "; read apellidos
			echo -n "Introduzca dirección: "; read direccion
			echo -n "Introduzca email: "; read email
			echo -n "Introduzca teléfono: "; read telefono
			echo $nombre":"$apellidos":"$direccion":"$email":"$telefono >> $ruta/$archivo 
			echo "Entrada creada con éxito en el archivo "$archivo
			;;
		#Borrar una entrada de la agenda
		3)	echo -n "Introduzca palabra clave: "; read clave
			#Variables auxiliarer que indica el número de registro e índice seleccionado
			reg_act=0
			indice_reg=0
			while read registro
			do
				#Incrementar el registro actual
				let reg_act++
				#Recorrer registro campo por campo
				for ((c=1; $c<=4; c++)) {
				
					#Se compara cada campo con la clave, si coincide se muestra por pantalla
					campo=`echo $registro | cut -d ":" -f $c`
					if [ "$clave" = "$campo" ]
					then
						let indice_reg++
						echo $indice_reg"." $registro
						seleccion[$indice_reg]=$reg_act
					fi
				}				
			done < $ruta/$archivo
			
			#Selección de la entrada a borrar
			echo -n "Seleccione una entrada: "; read n_entrada
			
			#Borrado	
			sed "${seleccion[$indice_reg]}d" $ruta/$archivo > $archivo.temp
			mv $ruta/$archivo.temp $ruta/$archivo
			echo "Entrada borrada"
			;;
		#Mostrar archivo ordenado por apellidos
		4)	sort -t':' -k2 $ruta/$archivo | tr ":" "	"
			;;
		#Terminar
		5)	exit 0
			;;
		#Error
		*)	echo Introduzca una opción válida
			;;
	esac
done


